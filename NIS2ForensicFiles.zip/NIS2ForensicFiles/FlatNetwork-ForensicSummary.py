import json
from collections import Counter, defaultdict

file_path = "eve1_copy--flat.json"

event_types = Counter()
alert_signatures = Counter()
src_dst_pairs = Counter()
ports = Counter()
stage_hits = defaultdict(list)

ATTACKER = "10.0.0.10"
WORKSTATION = "10.0.0.20"
METASPLOITABLE_SERVER = "10.0.0.30"
MONITOR = "10.0.0.100"


def add_stage(stage, obj):
    stage_hits[stage].append({
        "timestamp": obj.get("timestamp"),
        "event_type": obj.get("event_type"),
        "src_ip": obj.get("src_ip"),
        "src_port": obj.get("src_port"),
        "dest_ip": obj.get("dest_ip"),
        "dest_port": obj.get("dest_port"),
        "signature": obj.get("alert", {}).get("signature")
    })


with open(file_path, "r", encoding="utf-8", errors="ignore") as f:

    for line in f:
        line = line.strip()

        if not line:
            continue

        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue

        event_type = obj.get("event_type")
        src_ip = obj.get("src_ip")
        dest_ip = obj.get("dest_ip")
        dest_port = obj.get("dest_port")

        event_types[event_type] += 1

        if src_ip and dest_ip:
            src_dst_pairs[(src_ip, dest_ip)] += 1

        if dest_port:
            ports[dest_port] += 1

        if event_type == "alert":
            sig = obj.get("alert", {}).get("signature", "UNKNOWN")
            alert_signatures[sig] += 1

        # Stage 1: Reconnaissance
        if (
            src_ip == ATTACKER
            and event_type in ["alert", "flow"]
            and dest_ip in [WORKSTATION, METASPLOITABLE_SERVER]
        ):
            add_stage("Reconnaissance", obj)

        # Stage 2: Initial Access
        if (
            src_ip == ATTACKER
            and dest_ip == WORKSTATION
            and dest_port == 22
        ):
            add_stage("Initial Access", obj)

        # Stage 3: Lateral Movement
        if (
            src_ip == WORKSTATION
            and dest_ip == METASPLOITABLE_SERVER
        ):
            add_stage("Lateral Movement", obj)

        # Stage 4: Data Staging
        if (
            src_ip == METASPLOITABLE_SERVER
            and dest_ip == WORKSTATION
        ):
            add_stage("Data Staging", obj)

        # Stage 5: Data Exfiltration
        if (
            src_ip == WORKSTATION
            and dest_ip == MONITOR
        ):
            add_stage("Data Exfiltration", obj)


print("\n=== EVENT TYPE SUMMARY ===")
for k, v in event_types.most_common():
    print(f"{k}: {v}")

print("\n=== TOP ALERT SIGNATURES ===")
for k, v in alert_signatures.most_common(30):
    print(f"{v}  |  {k}")

print("\n=== TOP SOURCE - DESTINATION PAIRS ===")
for (src, dst), count in src_dst_pairs.most_common(20):
    print(f"{count}  |  {src} - {dst}")

print("\n=== TOP DESTINATION PORTS ===")
for port, count in ports.most_common(20):
    print(f"{count}  |  {port}")

print("\n=== ATTACK STAGE SUMMARY ===")
for stage, events in stage_hits.items():
    print(f"\n{stage}: {len(events)} related events")

    for e in events[:10]:
        print(e)